<template>
  <v-app>
    <router-view></router-view>
  </v-app>
</template>


