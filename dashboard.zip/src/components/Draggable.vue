<template>
  <v-row align="center" justify="center">
    <v-col cols="12" md="4" sm="4">
        <v-card elevation="1">
          <h3 class="text-center">Draggable 1</h3>
            <draggable :list="list1" group="people" @change="log">
              <v-list
                class="ma-3"
                elevation="2"
                v-for="(element, index) in list1"
                :key="element.name"
              >
                {{ element.name }} {{ index }}
              </v-list>
            </draggable>
        </v-card>
    </v-col>
    <v-row align="center" justify="center">
      <v-col cols="12" md="4" sm="4">
        <v-card elevation="0">
           <v-btn @click="pushAll">ALL</v-btn>
        </v-card>
    </v-col>
    </v-row>
    
    <v-col cols="12" md="4" sm="4">
        <v-card elevation="1">
          <h3 class="text-center">Draggable 2</h3>
            <draggable
              class="list-group"
              :list="list2"
              group="people"
              @change="log"
            >
              <v-list
                rounded
                class="ma-3"
                elevation="2"
                v-for="(element, index) in list2"
                :key="element.name"
              >
                {{ element.name }} {{ index }}
              </v-list>
            </draggable>
          
        </v-card>
    </v-col>
  </v-row>
    
  
</template>

<script>
import draggable from "vuedraggable";
export default {
  components: {
    draggable,
  },
  data: () => ({
   list1: [
      { name: "Victor", id: 1 },
      { name: "Ramon", id: 2 },
      { name: "Mario", id: 3 },
      { name: "Tablada", id: 4 }
    ],
    list2: [
      { name: "Fer", id: 5 },
      { name: "Paloma", id: 6 },
      { name: "Alejandra", id: 7 },
      { name: "Martha", id: 8 },
    ],
  }),
  methods: {
    log: function (evt) {
      window.console.log(evt);
      console.log("Tamaño lista1: " + this.list1.length);
    },
    pushAll() {
      console.log(this.list2.length);
      this.list1.forEach((item) => {
        this.list2.push(item);
      });
      console.log(this.list2.length);
      this.list1 = [];
    },
  },
};
</script>
