<template>
<v-container>
<h1>Maestro</h1>
<v-data-table
    v-model="selected" 
    :headers="headers"
    :items="desserts"
    :items-per-page="5"
    class="elevation-1"
    @click:row="datos" 
  >
  </v-data-table>
<TableDetalle :objeto="text" :porDato="text2"> </TableDetalle>
</v-container>
</template>
<script>

import TableDetalle from '@/components/TableDetalle.vue'

  export default {
      components: {
    TableDetalle,
  },
    data () {
      return {
        par: null,
        selected: [],
        headers: [
          { text: 'Dessert (100g serving)', align: 'start', sortable: false, value: 'name', },
          { text: 'Calories', value: 'calories' },
          { text: 'Fat (g)', value: 'fat' },
          { text: 'Carbs (g)', value: 'carbs' },
          { text: 'Protein (g)', value: 'protein' },
          { text: 'Iron (%)', value: 'iron' },    
        ],
        desserts: [
          { id: 1, name: 'Frozen Yogurt', calories: 159, fat: 6.0, carbs: 24, protein: 4.0, iron: '1%', },
          { id:2, name: 'Ice cream sandwich', calories: 237, fat: 9.0, carbs: 37, protein: 4.3, iron: '1%',
          },
        ],
      }
    },
    methods: {
        datos(desserts){
            console.log('El id es: '+ desserts.id);
            console.log('El nombre es  es: '+ desserts.name);
            console.log('El calorias es: '+ desserts.calories);
            console.log('El peso es: '+ desserts.fat);
            console.log('El carbos es: '+ desserts.carbs);
            console.log('El proteina es: '+ desserts.protein);
            console.log('El hierro es: '+ desserts.iron);
            this.par = desserts;
        },
    },
    computed: {
    text() {
      return this.par;
    },
    text2() {
      return 'Probando traspaso de objetos para tablas secundarias';
    },
    muestraTabla() {
      return true;
    }
  }
  }
</script>