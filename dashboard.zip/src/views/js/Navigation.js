export default {
     data: () => ({
        drawer: false,
        messages: 5,
        fav: true,
        menu: false,
        message: false,
        hints: true
      
    }),
    }