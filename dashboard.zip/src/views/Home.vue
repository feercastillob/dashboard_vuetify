          <v-list>
            <template v-slot:activator="{ on, attrs }">
              <v-list-item  @click="editItem(item)" v-bind="attrs" v-on="on">
                <v-list-item-title>Editar</v-list-item-title>
              </v-list-item>
            </template>
          </v-list>